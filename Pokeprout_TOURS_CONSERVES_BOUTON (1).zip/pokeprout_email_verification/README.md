# Pokeprout — vérification e-mail

Cette version ajoute une vraie vérification d'adresse e-mail côté serveur.

## Fonctionnement
- Création de compte : e-mail + mot de passe.
- Un code à 6 chiffres est envoyé par e-mail.
- Le code expire après 10 minutes.
- Maximum 5 demandes de code par adresse sur 15 minutes.
- Impossible de créer un second compte avec une adresse déjà vérifiée.
- Les nouveaux comptes commencent à 0 gemme et 0 tour.
- Les mots de passe sont hachés avec scrypt.
- Les comptes sont conservés dans `data/users.json` sur le serveur.

## Lancer
1. Installer Node.js 20+.
2. Dans ce dossier : `npm install`
3. Configurer les variables SMTP :
   - `SMTP_HOST`
   - `SMTP_PORT` (souvent 587)
   - `SMTP_SECURE` (`false` pour 587, `true` pour 465)
   - `SMTP_USER`
   - `SMTP_PASS`
   - `MAIL_FROM` (optionnel)
   - `ADMIN_KEY` (fortement recommandé de le changer)
4. Lancer : `npm start`

Le site sera sur `http://localhost:3000`.

## Important
GitHub Pages ne peut pas exécuter ce serveur Node. Pour avoir de vrais codes envoyés par e-mail et des comptes partagés entre appareils, il faut déployer ce dossier sur un hébergeur qui exécute Node.js et renseigner les variables SMTP.
