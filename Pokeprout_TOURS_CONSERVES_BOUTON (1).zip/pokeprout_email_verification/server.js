import express from 'express';
import nodemailer from 'nodemailer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import {fileURLToPath} from 'url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:'50kb'}));
app.use(express.static(path.join(__dirname,'public')));

const DATA=path.join(__dirname,'data','users.json');
if(!fs.existsSync(DATA)) fs.writeFileSync(DATA,JSON.stringify({users:{}},null,2));
const load=()=>JSON.parse(fs.readFileSync(DATA,'utf8'));
const save=x=>fs.writeFileSync(DATA,JSON.stringify(x,null,2));
const hash=p=>crypto.scryptSync(p, process.env.PASSWORD_PEPPER||'change-this-pepper',32).toString('hex');
const token=()=>crypto.randomBytes(32).toString('hex');
const code=()=>String(crypto.randomInt(100000,1000000));
const sessions=new Map();
const attempts=new Map();

function emailOk(e){return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)}
function clean(e){return String(e||'').trim().toLowerCase()}
function tooMany(key){
  const now=Date.now(), a=attempts.get(key)||[];
  const recent=a.filter(t=>now-t<15*60*1000); recent.push(now); attempts.set(key,recent);
  return recent.length>5;
}
function auth(req,res,next){
  const t=req.headers.authorization?.replace('Bearer ','');
  const email=t&&sessions.get(t);
  const db=load();
  if(!email||!db.users[email]||!db.users[email].verified) return res.status(401).json({error:'Connexion requise'});
  req.email=email; req.user=db.users[email]; next();
}
function mailer(){
  if(!process.env.SMTP_HOST) return null;
  return nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:String(process.env.SMTP_SECURE||'false')==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
}
async function sendCode(to,c){
  const tr=mailer();
  if(!tr) throw new Error('SMTP_NOT_CONFIGURED');
  await tr.sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to,subject:'Ton code de vérification Pokeprout',text:`Ton code de vérification Pokeprout est : ${c}\n\nCe code reste valable jusqu'à son utilisation. Si tu n'es pas à l'origine de cette demande, ignore cet e-mail.`});
}

app.post('/api/register',async(req,res)=>{
  const email=clean(req.body.email), password=String(req.body.password||'');
  if(!emailOk(email)||password.length<6) return res.status(400).json({error:'E-mail invalide ou mot de passe trop court (6 caractères minimum).'});
  if(tooMany(email)) return res.status(429).json({error:'Trop de demandes. Réessaie dans quelques minutes.'});
  const db=load(), old=db.users[email];
  if(old?.verified) return res.status(409).json({error:'Cette adresse e-mail possède déjà un compte.'});
  const c=code(); db.users[email]={passwordHash:hash(password),verified:false,verifyCodeHash:hash(c),gems:0,spins:0}; save(db);
  try{await sendCode(email,c);}catch(e){delete db.users[email];save(db);return res.status(503).json({error:'L’envoi d’e-mail n’est pas configuré sur le serveur.'});}
  res.json({ok:true,message:'Code envoyé à ton adresse e-mail.'});
});

app.post('/api/verify', (req,res)=>{
  const email=clean(req.body.email), c=String(req.body.code||'').trim(); const db=load(),u=db.users[email];
  if(!u) return res.status(400).json({error:'Compte introuvable.'});
  if(u.verified) return res.json({ok:true,message:'Compte déjà vérifié.'});
  if(hash(c)!==u.verifyCodeHash) return res.status(400).json({error:'Code incorrect.'});
  u.verified=true; delete u.verifyCodeHash; save(db);
  const t=token();sessions.set(t,email); res.json({ok:true,token:t,email,gems:0,spins:0});
});

app.post('/api/resend-code',async(req,res)=>{
  const email=clean(req.body.email); if(tooMany(email)) return res.status(429).json({error:'Trop de demandes. Réessaie dans quelques minutes.'});
  const db=load(),u=db.users[email]; if(!u||u.verified) return res.status(400).json({error:'Compte introuvable ou déjà vérifié.'});
  const c=code();u.verifyCodeHash=hash(c);save(db);
  try{await sendCode(email,c);}catch(e){return res.status(503).json({error:'L’envoi d’e-mail n’est pas configuré sur le serveur.'});}
  res.json({ok:true});
});

app.post('/api/login',(req,res)=>{const email=clean(req.body.email),p=String(req.body.password||''),db=load(),u=db.users[email];if(!u||u.passwordHash!==hash(p))return res.status(401).json({error:'E-mail ou mot de passe incorrect.'});if(!u.verified)return res.status(403).json({error:'Vérifie d’abord ton adresse e-mail.'});const t=token();sessions.set(t,email);res.json({ok:true,token:t,email,gems:u.gems,spins:u.spins});});
app.post('/api/logout',auth,(req,res)=>{const t=req.headers.authorization?.replace('Bearer ','');sessions.delete(t);res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({email:req.email,gems:req.user.gems,spins:req.user.spins}));
app.get('/api/leaderboard',(req,res)=>{const db=load();res.json(Object.entries(db.users).filter(([,u])=>u.verified).sort((a,b)=>(b[1].spins||0)-(a[1].spins||0)).slice(0,20).map(([email,u])=>({email,spins:u.spins||0,gems:u.gems||0})));});

app.post('/api/admin/give-gems', (req,res)=>{const key=req.headers['x-admin-key'];if(key!==(process.env.ADMIN_KEY||'POKEADMIN'))return res.status(403).json({error:'Accès refusé'});const email=clean(req.body.email),amount=Math.floor(Number(req.body.amount));const db=load(),u=db.users[email];if(!u||!u.verified||amount<1)return res.status(400).json({error:'Membre ou quantité invalide'});u.gems=(u.gems||0)+amount;save(db);res.json({ok:true,gems:u.gems});});
app.get('/api/admin/members',(req,res)=>{if(req.headers['x-admin-key']!==(process.env.ADMIN_KEY||'POKEADMIN'))return res.status(403).json({error:'Accès refusé'});const db=load();res.json(Object.entries(db.users).filter(([,u])=>u.verified).map(([email,u])=>({email,gems:u.gems||0,spins:u.spins||0})));});

const PORT=Number(process.env.PORT||3000);app.listen(PORT,()=>console.log(`Pokeprout sur http://localhost:${PORT}`));
